# This is the test Sparta app.

Use this repo to download the app on your EC2 or Azure instance using Git.
